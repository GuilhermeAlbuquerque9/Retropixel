using System.Collections.Generic;

namespace RetroNet
{
    public class History
    {
        private List<string> urls;

        public History()
        {
            urls = new List<string>();
        }

        public void Add(string url)
        {
            if (!urls.Contains(url))
            {
                urls.Add(url);
            }
        }

        public List<string> GetAll()
        {
            return urls;
        }
    }
}

