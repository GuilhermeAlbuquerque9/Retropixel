using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace RetroNet
{
    public class Form1 : Form
    {
        private TabControl tabControl;
        private Button addTabButton;
        private Button closeTabButton;
        private Button menuButton;
        private Button globalHomeButton;
        private List<string> favoritos = new List<string>();

        public Form1()
        {
            this.Text = "RetroNet v5.0";
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.LightGray;

            this.Resize += (s, e) => AdjustLayout();

            SetupTabBar();
            SetupGlobalHomeButton();
            AddNewTab(); // Abre a primeira guia com tela inicial
        }

        private void SetupTabBar()
        {
            tabControl = new TabControl()
            {
                Location = new Point(20, 60),
                Size = new Size(this.ClientSize.Width - 40, this.ClientSize.Height - 120),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };
            this.Controls.Add(tabControl);

            closeTabButton = new Button()
            {
                Text = "X",
                Location = new Point(20, 20),
                Width = 30,
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            closeTabButton.Click += (s, e) =>
            {
                if (tabControl.TabPages.Count > 0)
                    tabControl.TabPages.Remove(tabControl.SelectedTab);
            };

            addTabButton = new Button()
            {
                Text = "+",
                Location = new Point(60, 20),
                Width = 30,
                BackColor = Color.LightGreen,
                FlatStyle = FlatStyle.Flat
            };
            addTabButton.Click += (s, e) => AddNewTab();

            menuButton = new Button()
            {
                Text = "V",
                Location = new Point(this.ClientSize.Width - 50, 20),
                Width = 30,
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            menuButton.Click += (s, e) =>
            {
                ContextMenuStrip menu = new ContextMenuStrip();

                menu.Items.Add("⭐ Adicionar página aos favoritos", null, (sender, args) =>
                {
                    foreach (Control c in tabControl.SelectedTab.Controls)
                    {
                        if (c is WebBrowser browser)
                        {
                            favoritos.Add(browser.Url.ToString());
                            MessageBox.Show("Página adicionada aos favoritos!");
                            break;
                        }
                    }
                });

                menu.Items.Add("🏠 Voltar ao início", null, (sender, args) =>
                {
                    ShowHome(tabControl.SelectedTab);
                });

                menu.Items.Add("📄 Ver créditos e informações", null, (sender, args) =>
                {
                    MessageBox.Show("RetroNet v5.0\nDesenvolvido por PontoBat Sistemas™\nInspirado nos navegadores clássicos.");
                });

                menu.Items.Add("⭐👀 Ver favoritos", null, (sender, args) =>
                {
                    Form favForm = new Form()
                    {
                        Text = "Favoritos",
                        Size = new Size(400, 300),
                        StartPosition = FormStartPosition.CenterParent
                    };

                    ListBox favList = new ListBox()
                    {
                        Dock = DockStyle.Fill,
                        Font = new Font("Arial", 10)
                    };
                    favList.Items.AddRange(favoritos.ToArray());

                    favList.DoubleClick += (s2, e2) =>
                    {
                        if (favList.SelectedItem != null)
                        {
                            string url = favList.SelectedItem.ToString();
                            NavigateToUrl(tabControl.SelectedTab, url);
                            favForm.Close();
                        }
                    };

                    favForm.Controls.Add(favList);
                    favForm.ShowDialog();
                });

                menu.Items.Add("➡ Sair", null, (sender, args) =>
                {
                    Application.Exit();
                });

                menu.Show(menuButton, new Point(0, menuButton.Height));
            };

            this.Controls.Add(closeTabButton);
            this.Controls.Add(addTabButton);
            this.Controls.Add(menuButton);
        }

        private void SetupGlobalHomeButton()
        {
            globalHomeButton = new Button()
            {
                Text = "Voltar à tela inicial",
                Location = new Point(100, 20),
                Width = 150,
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat
            };
            globalHomeButton.Click += (s, e) =>
            {
                ShowHome(tabControl.SelectedTab);
            };
            this.Controls.Add(globalHomeButton);
        }

        private void AddNewTab()
        {
            TabPage tab = new TabPage("Nova guia");
            tab.BackColor = Color.White;
            tab.Padding = new Padding(10);
            tabControl.TabPages.Add(tab);
            tabControl.SelectedTab = tab;
            ShowHome(tab);
        }

        private void ShowHome(TabPage tab)
        {
            tab.Controls.Clear();

            Label titleLabel = new Label()
            {
                Text = "RetroNet",
                Font = new Font("Arial", 32, FontStyle.Bold),
                Location = new Point(370, 100),
                AutoSize = true
            };

            Label subtitleLabel = new Label()
            {
                Text = "A experiência Web mais retrô hoje em dia!",
                Font = new Font("Arial", 14, FontStyle.Italic),
                Location = new Point(300, 150),
                AutoSize = true
            };

            TextBox urlBar = new TextBox()
            {
                Width = 600,
                Location = new Point(200, 200),
                Font = new Font("Arial", 12)
            };

            Button searchButton = new Button()
            {
                Text = "Pesquisar",
                Location = new Point(810, 200),
                Width = 80,
                BackColor = Color.LightBlue,
                FlatStyle = FlatStyle.Flat
            };

            urlBar.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                    NavigateToUrl(tab, urlBar.Text);
            };
            searchButton.Click += (s, e) => NavigateToUrl(tab, urlBar.Text);

            Label copyright = new Label()
            {
                Text = "© PontoBat Sistemas™, 2025. Todos os direitos reservados.",
                Font = new Font("Arial", 10),
                ForeColor = Color.Gray,
                Location = new Point(320, tab.Height - 60),
                AutoSize = true
            };

            tab.Controls.Add(titleLabel);
            tab.Controls.Add(subtitleLabel);
            tab.Controls.Add(urlBar);
            tab.Controls.Add(searchButton);
            tab.Controls.Add(copyright);
        }

        private void NavigateToUrl(TabPage tab, string input)
        {
            string url = input.Trim();
            if (!url.StartsWith("http")) url = "https://" + url;

            tab.Controls.Clear();

            TextBox addressBar = new TextBox()
            {
                Width = 700,
                Location = new Point(20, 5),
                Font = new Font("Arial", 10)
            };

            WebBrowser browser = new WebBrowser()
            {
                Location = new Point(0, 35),
                Size = new Size(tab.Width - 20, tab.Height - 60),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                ScriptErrorsSuppressed = true
            };

            addressBar.Text = url;
            addressBar.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    string newUrl = addressBar.Text.Trim();
                    if (!newUrl.StartsWith("http")) newUrl = "https://" + newUrl;
                    browser.Navigate(newUrl);
                }
            };

            browser.DocumentCompleted += (s, e) =>
            {
                tab.Text = browser.DocumentTitle;
                addressBar.Text = browser.Url.ToString();
            };

            browser.Navigate(url);
            tab.Controls.Add(addressBar);
            tab.Controls.Add(browser);
        }

        private void AdjustLayout()
        {
            tabControl.Size = new Size(this.ClientSize.Width - 40, this.ClientSize.Height - 120);
            menuButton.Location = new Point(this.ClientSize.Width - 50, 20);
        }
    }
}
