using System.Collections.Generic;

namespace RetroNet
{
    public class Favorites
    {
        private List<string> urls;

        public Favorites()
        {
            urls = new List<string>();
        }

        public void Add(string url)
        {
            if (!urls.Contains(url))
            {
                urls.Add(url);
            }
        }

        public List<string> GetAll()
        {
            return urls;
        }
    }
}
